import { Component } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  dersler: any;

  constructor() {}

  ngOnInit() {
    console.log("bilgi gelsin");

    fetch("http://localhost/api/derslerim.php").then(gelenVeri => gelenVeri.json())
    .then(json => {
      this.dersler = (json);
      console.log(this.dersler);
      console.log(this.dersler[0].derslerinIsmi);
      
    })
  }

}
